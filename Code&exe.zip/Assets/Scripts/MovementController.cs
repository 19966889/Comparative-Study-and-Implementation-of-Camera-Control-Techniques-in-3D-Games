using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class MovementController : MonoBehaviour
{
    public float walkSpeed = 5f;
    public float runSpeed = 10f;
    public float gravity = 20f;
    public float jumpForce = 8f;

    private Vector3 moveDirection = Vector3.zero;   // The direction of the avatar 
    private CharacterController characterController; //
    private Transform mainCamera;

    private void Start()
    {
        characterController = GetComponent<CharacterController>();
        mainCamera = Camera.main.transform;
    }

    private void Update()
    {
        HandleMovement();
    }

    private void HandleMovement()
    {
        if (characterController.isGrounded) //check if the avartar is on the ground

        {
            float speed;
            if (Input.GetKey(KeyCode.LeftShift))    //Press shift to dash
            {
                speed = runSpeed;
            }
            else
            {
                speed = walkSpeed;
            }

            // Get input for movement
            float moveX = Input.GetAxis("Horizontal");
            float moveZ = Input.GetAxis("Vertical");
            
            // Calculate movement direction
            Vector3 forward = mainCamera.forward;
            Vector3 right = mainCamera.right;
            forward.y = 0; 
            right.y = 0;   
            forward.Normalize();
            right.Normalize();

            moveDirection = (forward * moveZ + right * moveX).normalized;   //Final move direction
            moveDirection *= speed;

            //Set the forward direction to the move direction
            if (moveDirection.magnitude > 0.01f)
            {
                transform.forward = moveDirection.normalized;
            }

            if (Input.GetButtonDown("Jump"))    //// Jump
            {
                moveDirection.y = jumpForce;
            }
        }
        else
        {
            // If avatar is not on the ground
            moveDirection.y -= gravity * Time.deltaTime;
        }

        // Apply the movement
        characterController.Move(moveDirection * Time.deltaTime);
    }
}
