using UnityEngine;

public class ThirdPersonCameraController : MonoBehaviour
{
    public Transform target;
    public Vector3 initialOffset = new Vector3(0, 2, -5);
    public float sensitivity = 2f;
    public float upLimit = 80f;
    public float downLimit = -40f;
    public float zoomSpeed = 2f;
    public float maxZoom = 5f;
    public float minZoom = 2f;
    public LayerMask collisionMask; //Detect that the camera can collide
    public CameraCollisionTransparency transparencyHandler; 
    public float transparencyDistance = 0.6f; //Make avatar transparent
    private float currentZoom;
    private float yaw;
    private float pitch;

    private void Start()
    {
        currentZoom = -initialOffset.z;
        pitch = 0f;
        yaw = 0f;
    }

    private void Update()
    {
        HandleZoom();
        HandleRotation();
    }

    private void LateUpdate()
    {
        UpdateCameraPosition();
    }

    private void HandleZoom()   //Use scroll to zoom in or out
    {
        currentZoom -= Input.GetAxis("Mouse ScrollWheel") * zoomSpeed;
        currentZoom = Mathf.Clamp(currentZoom, minZoom, maxZoom);
    }

    private void HandleRotation()   //Camera rotation
    {
        pitch -= sensitivity * Input.GetAxis("Mouse Y");
        yaw += sensitivity * Input.GetAxis("Mouse X");
        pitch = Mathf.Clamp(pitch, downLimit, upLimit); //Limit the angle
    }

    private void UpdateCameraPosition()
    {
        Vector3 desiredPosition = target.position + Quaternion.Euler(pitch, yaw, 0) * new Vector3(0, 0, -currentZoom);
        
        if (Physics.Linecast(target.position, desiredPosition, out RaycastHit hit, collisionMask))  // Check if any thing block the camera and avatar 
        {
            desiredPosition = hit.point;    //Set camera position to the point of collision
        }

        transform.position = desiredPosition;
        transform.LookAt(target);

        float distanceToPlayer = Vector3.Distance(transform.position, target.position);
        if (distanceToPlayer < transparencyDistance)    //If the distance between the camera and the avatar is too close, set the avatar to be transparent to have better view
        {
            transparencyHandler.SetTransparency(true); 
        }
        else
        {
            transparencyHandler.SetTransparency(false);
        }
    }
}
