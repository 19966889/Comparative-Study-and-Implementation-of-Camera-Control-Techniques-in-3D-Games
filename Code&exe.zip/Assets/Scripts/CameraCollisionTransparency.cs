using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraCollisionTransparency : MonoBehaviour
{
    public Transform target;
    public float transparencyValue = 0.2f;
    private Renderer[] characterRenderers; //Create an array to store renderer
    private bool isTransparent = false;

    void Start()
    {
        characterRenderers = target.GetComponentsInChildren<Renderer>();    //get all renderer
    }

    public void SetTransparency(bool makeTransparent)
    {
        if(makeTransparent && !isTransparent)   //Check if avatar is not transparent
        {
            for (int i = 0; i < characterRenderers.Length; i++)
            {
                Renderer r = characterRenderers[i];
                if(r.material.HasProperty("_Color"))
                {
                    Color color = r.material.color;
                    color.a = transparencyValue;
                    r.material.color = color;
                }
            }
            isTransparent = true;
        }
        else if(!makeTransparent && isTransparent)  //Check if avatar is transparent
        {
            for (int i = 0; i < characterRenderers.Length; i++)
            {
                Renderer r = characterRenderers[i];
                if(r.material.HasProperty("_Color"))
                {
                    Color color = r.material.color;
                    color.a = 1;
                    r.material.color = color;
                }
            }
            isTransparent = false;
        }
    }
}
